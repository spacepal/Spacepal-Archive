<template>
  <div id="game-title">Space<sup>Pal</sup></div>
</template>

<script>
export default {
  name: 'GameTitle'
}
</script>

<style lang="scss" scoped>
@import '../css/components/_game_title.scss';
</style>
