
export default {
  neutral: { bg: 'rgb(50, 50, 50)', text: 'white' },
  1: { bg: '#26537C', text: 'white' },
  2: { bg: '#6A237E', text: 'white' },
  3: { bg: '#8BB42D', text: 'white' },
  4: { bg: '#BF8430', text: 'white' },
  5: { bg: '#BF3730', text: 'white' },
  6: { bg: '#1D7074', text: 'white' },
  7: { bg: '#498D43', text: 'white' },
  8: { bg: '#FFE440', text: 'black' }
}
// rgb(10, 100, 80)
