export const HOST = 'http://0.0.0.0:3000'
export const API_URL = `${HOST}/api/`
