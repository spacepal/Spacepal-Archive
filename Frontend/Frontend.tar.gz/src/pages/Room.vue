<template>
  <div>Room page</div>
</template>

<script>
export default {
  name: 'Room'
}
</script>
