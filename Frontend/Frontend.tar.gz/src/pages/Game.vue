<template>
  <div>Game page</div>
</template>

<script>
export default {
  name: 'Game'
}
</script>
